
library(corrplot)
library(PerformanceAnalytics)


derate_data_full = readRDS("derate.ini")

derate_data = derate_data_full[,c(2,7,8,9,10)]

derate_data$agw[is.na(derate_data$agw)] = mean(derate_data$agw,na.rm = T)
derate_data$delfn[is.na(derate_data$delfn)] = mean(derate_data$delfn,na.rm = T)
#derate_data$ztla[is.na(derate_data$ztla)] = mean(derate_data$ztla,na.rm = T)
derate_data$zalt[is.na(derate_data$zalt)] = mean(derate_data$zalt,na.rm = T)
derate_data = derate_data[which(!is.na(derate_data$ztla)),]

hist(derate_data$agw)

model = lm(delfn~., data = derate_data)
summary(model)
plot(model)

model2 = lm(delfn~agw+ztla+zalt, data = derate_data)
summary(model2)
plot(model2)

derate_data = derate_data[which(rownames(derate_data)!=1752),] #Outlier
derate_data = derate_data[which(rownames(derate_data)!=1710),] #Outlier

model3 = lm(delfn~., data = derate_data)
summary(model3)
plot(model3)

model4 = lm(sqrt(delfn)~., data = derate_data)
summary(model4)
plot(model4)

library(nortest)
ad.test(residuals(model4))


derate_data = derate_data[which(derate_data$agw>20000 & derate_data$agw<250000),] #Outlier

derate_data = derate_data[which(derate_data$delfn>=0),] 

model5 = lm(sqrt(delfn)~., data = derate_data)
summary(model5)
plot(model5)

plot(derate_data$agw,residuals(model5))  ## Checking any non-linearity of predictor variables
plot(derate_data$ztla,residuals(model5))
plot(derate_data$zalt,residuals(model5))

plot(derate_data$delfn,residuals(model5))

library(MASS)
bc <- boxcox(delfn ~ ., data = derate_data,
       lambda = seq(-10, 10, length = 100))

lambda <- bc$x[which.max(bc$y)]


derate_data$delfn = (((derate_data$delfn)^lambda)-1)/lambda

model6 = lm(delfn~engine_type+agw+ztla+zalt, data = derate_data)
summary(model6)
plot(model6)

plot(derate_data$agw,residuals(model6))  ## Checking any non-linearity of predictor variables
plot(derate_data$ztla,residuals(model6))
plot(derate_data$zalt,residuals(model6))

plot(derate_data$delfn,residuals(model6))
plot(fitted.values(model6),residuals(model6))

derate_data$engine_type = substr(derate_data$engine_type,start = 1,stop = 10)

model7 = lm(delfn~engine_type+agw+ztla+zalt, data = derate_data)
summary(model7)
plot(model7)

plot(derate_data$agw,residuals(model7))  ## Checking any non-linearity of predictor variables
plot(derate_data$ztla,residuals(model7))
plot(derate_data$zalt,residuals(model7))

plot(derate_data$delfn,residuals(model7))
plot(fitted.values(model7),residuals(model7))


corrplot(cor(derate_data), type = "upper", order = "hclust", 
         tl.col = "black", tl.srt = 45)

chart.Correlation(derate_data[,c(2,3,4,5)], histogram=TRUE, pch=19)
